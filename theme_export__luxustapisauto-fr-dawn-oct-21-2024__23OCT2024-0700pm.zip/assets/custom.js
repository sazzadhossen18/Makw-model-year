var errorMessage = "Veuillez sélectionner la marque, l'année et le modèle de votre véhicule";

$('#modelyear').change(function(){ 
  
$('#make').empty();
$('select#make').append('<option value="">Marque</option>'); 
  
  $('#models').html("");
  $('#models').append("<option value=''>Modèle</option>");

  
   $('#getMakesFromHere').find("option").each(function(i, item){
    var cls = $(this).attr('attr-class');
    $('#make').append("<option attr-class='"+cls+"' value='"+item.value+"'>"+item.text+"</option>");
  });

  
});
  
$('#make').change(function(){
  /*
  $('#modelyear').empty();
  $('select#modelyear').append('<option value="">Year</option>');
  */
  
  $('#models').html("");
  $('#models').append("<option value=''>Model</option>");
  var attr_class = $( "#make option:selected" ).attr("attr-class");
  $('#model-hidden').find("option").each(function(){
    var cls = $(this).attr('class');
    cls = $.trim(cls);
    attr_class = $.trim(attr_class);
    if (cls == attr_class) {
      var txt = $(this).text();
      txt = $.trim(txt);
      var startyear = $(this).attr('startyear');
      $('#models').append("<option startyear='"+startyear+"' value='"+txt+"'>"+txt+"</option>");
    }
  });
});

$('#models').change(function(){    
/*
  $('select#modelyear').empty();
  $('select#modelyear').append('<option value="">Year</option>');
  var startyear = $( "#models option:selected" ).attr("startyear");

  var today = new Date();
  var yearfull = today.getFullYear();
  for (i = yearfull; i >= startyear; i--) {
    $('select#modelyear').append('<option value="'+i+'">'+i+'</option>');
  }
  */
});


  
$(document).ready(function(){
  $('.btn--find').click(function(){
    var make  = $('#make').val(),
        model = $('#models').val(),
        modelyear = $('#modelyear').val();
    if(make == "" || model == "" || modelyear == ""){
      $('html, body').animate({
        scrollTop: $(".error").offset().top-300
      }, 500);
      $('.error').html('<p>'+errorMessage+'</p>');
      setTimeout(function(){ 
        $('.btn--find').removeClass('btn--loading');
      }, 2000);
    }else{
      window.location.href = 'https://' + document.domain + '/collections?model_filter=Make:'+ make + '+Model:'+ model + '+Year:' + modelyear;
    }
  });

  $('select').change(function(){
    $('.error').html('');
  });
});
  
  
  
  function myFunction() {
    
  var x = document.getElementById("models").value;
     var x1 = document.getElementById("make").value;
     var x2 = document.getElementById("modelyear").value; 
    
    localStorage.setItem("Model", x);
     localStorage.setItem("make", x1);
     localStorage.setItem("modelyear", x2);

   var res= localStorage.getItem("Model");
    
    console.log(res);
    
}
  
  





document.addEventListener("DOMContentLoaded", function () {
  let model_filters = {
    Make: null,
    Model: null,
    Year: null,
  };

  let carPropertiesContainer = document.getElementById(
    "car-properties-container"
  );
  if (!carPropertiesContainer) return;

  if (document.body.classList.contains("template-index")) {
    carPropertiesContainer.addEventListener("change", function (event) {
      let targetElem = event.target;
      switch (targetElem.name) {
        case "properties[Make]":
          model_filters.Make = targetElem.value;
          break;
        case "properties[Model]":
          model_filters.Model = targetElem.value;
          break;
        case "properties[Year]":
          model_filters.Year = targetElem.value;
          break;
        default:
          return;
      }

      sessionStorage.setItem("model_filters", JSON.stringify(model_filters));
      //     console.log(event);
    });

if(sessionStorage.getItem("model_filters")!=null)
{
    model_filters = JSON.parse(sessionStorage.getItem("model_filters"));
    let yearSelect = document.getElementById("modelyear");
    let makeSelect = document.getElementById("make");
    let modelSelect = document.getElementById("models");
    


    if(model_filters)
    {yearSelect.value = model_filters.Year;
    yearSelect.dispatchEvent(new Event("change"));
    }
    
    if(model_filters)
    {makeSelect.value = model_filters.Make;
    makeSelect.dispatchEvent(new Event("change"));
    }
    
     if(model_filters)
     {modelSelect.value = model_filters.Model;
     modelSelect.dispatchEvent(new Event("change"));
     }
}
    
  } else if (document.body.classList.contains("template-product")) {
    
    model_filters = JSON.parse(sessionStorage.getItem("model_filters"));
    let yearSelect = document.getElementById("modelyear");
    let makeSelect = document.getElementById("make");
    let modelSelect = document.getElementById("models");
    


    if(model_filters)
    {yearSelect.value = model_filters.Year;
    yearSelect.dispatchEvent(new Event("change"));
    }
    
    if(model_filters)
    {makeSelect.value = model_filters.Make;
    makeSelect.dispatchEvent(new Event("change"));
    }
    
     if(model_filters)
     {modelSelect.value = model_filters.Model;
     modelSelect.dispatchEvent(new Event("change"));
     }
      
  }
});



 $(document).ready(function() {
    $('ul.tabs').each(function(){
      var active, content, links = $(this).find('a');
      active = links.first().addClass('active');
      content = $(active.attr('href'));
      links.not(':first').each(function () {
        $($(this).attr('href')).hide();
      });
      $(this).find('a').click(function(e){
        active.removeClass('active');
        content.hide();
        active = $(this);
        content = $($(this).attr('href'));
        active.addClass('active');
        content.show();
        return false;
      });
    });
//    $(function() {
//      // (Optional) Active an item if it has the class "is-active"	
//      $("#mobile-tabs .accordion-item.is-active").children(".accordion-panel").slideDown();

//      $("#mobile-tabs .accordion-item .accordion-thumb").click(function() {
//        // Cancel the siblings
      
//  	  $(this).parent().siblings(".accordion-item").removeClass("is-active").children(".accordion-panel").slideUp();
//        // Toggle the item
//        $(this).parent().toggleClass("is-active").children(".accordion-panel").slideToggle("ease-out");
      
//      });
//    });
   
  
     var res= localStorage.getItem("Model"); 
   
   
   
  });

 var acc = document.getElementsByClassName("up_accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("is-active");
    var panel = this.nextElementSibling;
   
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    
       $(this).parent().siblings(".accordion-item").removeClass("is-active").children(".accordion-panel");
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
      
        $(this).parent().toggleClass("is-active");
      
    }
  });
}

 var res= localStorage.getItem("make");
 var res1= localStorage.getItem("Model");
 var res2= localStorage.getItem("modelyear");



if(res==null){
res='';
}

if(res1==null){
res1='véhicule exact ';}

if(res2==null){
  res2='';
}
function setTexts()
  {
$(".test").text(res+ " " +res1+" "+res2 );
jQuery('#result').html(res+' '+res1+' '+res2);
  }setTexts();
document.addEventListener("cart:change", (event) => {
setTexts();
});document.addEventListener("submit", (event) => {
setTimeout(function(){setTexts();},2000);
});  
document.addEventListener("pageshow", (event) => {
setTexts();
});
 


  $(document).ready(function() {
    var Delay = 500, ToolTipTimer
    $('.tooltip').hover(function(e){
      var title = $(this).attr('title');
      $(this).data('ToolTipText', title).removeAttr('title');
      $('<div class="wy-tooltip wy-hide"></div>').html(title).appendTo(document.body);
      ToolTipTimer  = setTimeout(function(e) {
        $('.wy-tooltip').removeClass('wy-hide').fadeIn('fast');
      },Delay);
    }, function() {
      clearTimeout(ToolTipTimer);
      $(this).attr('title', $(this).data('ToolTipText'));
      $('.wy-tooltip').remove();
    }).mousemove(function(e) {
      var pLeft;
      var pTop;
      var offset = 10;
      var CursorX = e.pageX;
      var CursorY = e.pageY;
      var WindowWidth = $(window).width();
      var WindowHeight = $(window).height();
      var toolTip = $('.wy-tooltip');
      var TTWidth = toolTip.width();
      var TTHeight = toolTip.height();			
      if (CursorX-offset >= (WindowWidth/4)*3) {
        pLeft = CursorX - TTWidth - offset;
      } else {
        pLeft = CursorX + offset;
      }
      if (CursorY-offset >= (WindowHeight/4)*3) {
        pTop = CursorY - TTHeight - offset;
      } else {
        pTop = CursorY + offset;
      }
      $('.wy-tooltip').css({ top: pTop, left: pLeft })			
    });







var customImage=document.querySelector('#withLogoImage');
  if(customImage)
  {
    
  }

    
  });

function resetLogoBlock()
  {
  
  }
function setLogoBlock()
  { 
   
  }


function resetLogoBlock2()
  {
  
  }
function setLogoBlock2()
  {
  
  }









function collSet()
{

  var customImage=document.querySelector('#withLogoImage2');
  if(customImage)
  {
    
  }

  
$('#modelyear2').change(function(){   
$('#make2').empty();
$('select#make2').append('<option value="">Marque</option>'); 
  
  $('#models2').html("");
  $('#models2').append("<option value=''>Modèle</option>");

  
   $('#getMakesFromHere2').find("option").each(function(i, item){
    var cls = $(this).attr('attr-class');
    $('#make2').append("<option attr-class='"+cls+"' value='"+item.value+"'>"+item.text+"</option>");
  });

  
});
  
$('#make2').change(function(){
  /*
  $('#modelyear').empty();
  $('select#modelyear').append('<option value="">Year</option>');
  */
  
  $('#models2').html("");
  $('#models2').append("<option value=''>Model</option>");
  var attr_class = $( "#make2 option:selected" ).attr("attr-class");
  $('#model-hidden2').find("option").each(function(){
    var cls = $(this).attr('class');
    cls = $.trim(cls);
    attr_class = $.trim(attr_class);
    if (cls == attr_class) {
      var txt = $(this).text();
      txt = $.trim(txt);
      var startyear = $(this).attr('startyear');
      $('#models2').append("<option startyear='"+startyear+"' value='"+txt+"'>"+txt+"</option>");
    }
  });
});

$('#models2').change(function(){    
/*
  $('select#modelyear').empty();
  $('select#modelyear').append('<option value="">Year</option>');
  var startyear = $( "#models option:selected" ).attr("startyear");

  var today = new Date();
  var yearfull = today.getFullYear();
  for (i = yearfull; i >= startyear; i--) {
    $('select#modelyear').append('<option value="'+i+'">'+i+'</option>');
  }
  */
});

    model_filters = JSON.parse(sessionStorage.getItem("model_filters"));
    let yearSelect2 = document.getElementById("modelyear2");
    let makeSelect2 = document.getElementById("make2");
    let modelSelect2 = document.getElementById("models2");
    


    if(model_filters)
    {yearSelect2.value = model_filters.Year;
    yearSelect2.dispatchEvent(new Event("change"));
    }
    
    if(model_filters)
    {makeSelect2.value = model_filters.Make;
    makeSelect2.dispatchEvent(new Event("change"));
    }
    
     if(model_filters)
     {modelSelect2.value = model_filters.Model;
     modelSelect2.dispatchEvent(new Event("change"));
     }

}























/*
referesh cart 
document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
    bubbles: true
  }));
*/

/*
function updatePrice()
{
var price = document.querySelector('select#warrantyId').selectedOptions[0].getAttribute("data-price");
document.getElementById("warrantyPrice").innerHTML = price;

var image = document.querySelector('select#warrantyId').selectedOptions[0].getAttribute("data-image");
document.getElementById("warrantyImage").src = image;
}
function addGuarantee()
{
var idVal = parseInt(document.querySelector("#warrantyId").value);
$.ajax({
type: 'POST',
url: '/cart/add.js',
data: {
  quantity: 1,
  id: idVal
},
  dataType: 'json', 
 success: function (data) { 
document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
    bubbles: true
  })); 
 } 
});

}

*/